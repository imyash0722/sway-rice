setlocal statuscolumn=""
