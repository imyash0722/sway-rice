return {
  "ggandor/flit.nvim",
  dependencies = {
    "https://codeberg.org/andyg/leap.nvim",
  },
  event = "VeryLazy",
  config = true,
}
