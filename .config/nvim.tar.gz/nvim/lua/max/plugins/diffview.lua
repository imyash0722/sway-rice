return {
  "sindrets/diffview.nvim"
}
